package me.stec.jni;

public class Main {

	/**
	 * Main function of the jar (with empty body)
	 * 
	 * @param args
	 * @throws XCryptException 
	 */
	public static void main(String[] args) throws XCryptException {
	}

}
